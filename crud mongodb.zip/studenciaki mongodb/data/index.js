const userDate = require('./users');

module.exports = {
  users: userDate,
};
